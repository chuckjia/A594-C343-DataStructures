import java.awt.Color;
/*
 * Author: Chuck Jia
 * 
 */

public class TableElem {
	public int key;
	public long value;

	TableElem(int key, long value){
		this.key = key;
		this.value = value;
	}
}
